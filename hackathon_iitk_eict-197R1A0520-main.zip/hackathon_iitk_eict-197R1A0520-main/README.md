# DataScienceHackathon
### File name should be your hackathon_ID.ipynb
### e.g. for individuals file name : DS_EICT2005.ipynb and for Team TDS_EICT2001.ipynb

